﻿namespace ECommerce.Domain.Entities;

public enum Status
{
    Pending,
    Approved,
    Shiped,
    Delivered,
    Canceled
}