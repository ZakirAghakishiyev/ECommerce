﻿namespace ECommerce.Domain.Entities;

public class Entity
{
    public int Id { get; set; }
}
