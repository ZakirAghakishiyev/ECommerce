﻿namespace ECommerce.Domain.Entities;

public enum Roles
{
    Seller,
    Customer
}
