﻿using ECommerce.Domain.Entities;
using static ECommerce.Domain.Entities.Product;

namespace ECommerce.Domain.Interfaces;

public interface IOrderRepository : IRepository<Order>
{
}