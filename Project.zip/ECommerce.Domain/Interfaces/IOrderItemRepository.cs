﻿using ECommerce.Domain.Entities;

namespace ECommerce.Domain.Interfaces;

public interface IOrderItemRepository : IRepository<OrderItem>
{

}
