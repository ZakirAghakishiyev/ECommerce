﻿using ECommerce.Application.DTOs;
using ECommerce.Application.Interfaces;
using ECommerce.Application.Services;
using ECommerce.Domain.Entities;
using ECommerce.Domain.Interfaces;
using ECommerce.Infrastructure.EfCore;
using ECommerce.Infrastructure.EfCore.Context;

namespace ECommerce.UI
{
    internal class Program
    {
        static void Main(string[] args)
        {
            AppDbContext appDbContext = new();
            ICategoryRepository categoryRepository = new CategoryRepository(appDbContext);
            ICategoryService categoryService = new CategoryManager(categoryRepository);

            IUserRepository UserRepository = new UserRepository(appDbContext);
            IUserService UserService = new UserManager(UserRepository);

            IOrderRepository OrderRepository = new OrderRepository(appDbContext);
            IOrderService OrderService = new OrderManager(OrderRepository);

            //categoryService.Add(new CategoryCreateDto { Name = "Fruit" });
            //categoryService.Update(new CategoryUpdateDto { Id=3, Name = "Baverages" });

            //UserService.Add(new UserCreateDto {FirstName="Zakir", LastName="Aghakishiyev", Password="1234", Email="zakirq781@gmail.com", Role=(Roles)2});
            //UserService.Add(new UserCreateDto {FirstName="Iker", LastName="Casillas", Password="Ik1", Email="ikerc1@gmail.com", Role=(Roles)1});

            //Printer.UsersPrinter(UserService.GetAll(null,false));

            //OrderService.Add(new OrderCreateDto { UserId = 1, Status = (Status)1, Items = new List<OrderItemDto> { } });
            //OrderService.Add(new OrderCreateDto { UserId = 1, Status = (Status)3, Items = new List<OrderItemDto> { } });
            //OrderService.Update(new OrderUpdateDto { Id = 1, Status = (Status)2 });
            //Printer.OrderPrinter(OrderService.GetById(1));

            Printer.UserPrinter(UserService.GetById(1));
        }
    }
}
